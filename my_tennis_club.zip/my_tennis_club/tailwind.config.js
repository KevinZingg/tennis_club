/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./members/templates/**/*.html'],
  theme: {
    extend: {},
  },
  plugins: [],
}

