from django.contrib import admin
from .models import TennisCourt, Booking

admin.site.register(TennisCourt)
admin.site.register(Booking)